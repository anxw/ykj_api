import os
import sys
from unittest import TestLoader
from lib import create_and_get_report
from lib import BSTestRunner

sys.path.append(os.path.split(os.path.abspath(os.path.dirname(__file__)))[0])




def test_case_dicovery(dir_name=None, pattern='*.py',top_lever_file=None):
    """加载某文件下所有.py下的测试用例，并返回suite(一个套件)"""
    if dir_name is None:
        suite = TestLoader().discover('.')
    else:
        suite = TestLoader().discover(start_dir=dir_name,pattern=pattern,top_level_dir=top_lever_file)

    return suite


def main(suite, report_name, title='接口测试报告', description='营销云接口测试'):
    report_template = create_and_get_report(report_name)
    with open(report_template,'wb') as f:
        runner = BSTestRunner(stream=f, title=title, description=description,verbosity=2)
        runner.run(suite)
        
        
if __name__=='__main__':
    suite = test_case_dicovery('testCases', 'test_demo.py')
    main(suite, '接口测试报告')
