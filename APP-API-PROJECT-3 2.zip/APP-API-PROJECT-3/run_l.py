# coding:utf-8
import os
import sys
import subprocess
sys.path.append(os.path.split(os.path.abspath(os.path.dirname(__file__)))[0])


def main(num=0, file_name='testCases/locust_demo.py'):
    if num == 1:
        """ 运行测试用例一次，可用于接口测试 """
        pipe = subprocess.Popen(['locust','-f',file_name,'-c','1','-r','1','-n','1','--no-web'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        r = pipe.communicate()
        print(r)
    elif num == 0:
        """ 单个接口的压力测试，默认打开网址：http://127.0.0.1:8089 """
        pipe = subprocess.Popen(['locust', '-f', file_name],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        r = pipe.communicate()
        print(r)
    else:
        raise ValueError('参数 num 的取值错误！')


if __name__ == '__main__':
    main(0)