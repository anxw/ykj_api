from lib import SubSession
import unittest

from lib import logger


class Topic_init(unittest.TestCase):

    def setUp(self):
        self.hs = SubSession("https://napi.yonyoucloud.com/")

    def test_getFansListByTopic(self):
        """话题粉丝列表"""

        reponse = self.hs.req_func('Topic_yaml/getFansListByTopic.yaml')
        logger.info(reponse.text)
        assert reponse.json()['error_description'] == '操作成功'
        assert reponse.status_code == 200, '接口请求错误！返码错误！返回状态'
        # assert reponse.json()['error_code'] == 0
        # assert reponse.status_code == 200, '接口请求错误！返码错误！回状态'


if __name__ == '__main__':
    unittest.main()