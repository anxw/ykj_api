# coding:utf-8
from lib import SubSession
import unittest
from lib import logger


class Test01(unittest.TestCase):
    def setUp(self):
        self.hs = SubSession("http://123.103.9.204:6058/")

    def test_getDiaryLikeList(self):
        """团队日志"""
        # global reponse

        resp = self.hs.req_func_light('Diary_yaml/getDiaryLikeList.yaml')
        logger.info(resp.text)
        assert resp.status_code == 200, '接口请求错误！返码错误！返回状态'
        # assert reponse.json()['error_code'] == 0


if __name__ == '__main__':
    unittest.main()