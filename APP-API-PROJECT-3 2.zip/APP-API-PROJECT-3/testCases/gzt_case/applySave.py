from lib import SubSession
import unittest

from lib import logger


class Topic_init(unittest.TestCase):

    def setUp(self):
        self.hs = SubSession("http://123.103.9.204:92/")

    def test_applySave(self):
        """获取插件列表"""

        reponse = self.hs.req_func('gzt_yaml/applySave.yaml')
        logger.info(reponse.text)
        assert reponse.json()['error_description'] == '操作成功'
        assert reponse.status_code == 200, '接口请求错误！返码错误！返回状态'
        # assert reponse.json()['error_code'] == 0
        # assert reponse.status_code == 200, '接口请求错误！返码错误！回状态'


if __name__ == '__main__':
    unittest.main()