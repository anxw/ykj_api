from testCases.dt_case.detail24 import *
