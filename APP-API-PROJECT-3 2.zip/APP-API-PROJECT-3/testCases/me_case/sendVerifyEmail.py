from lib import SubSession
import unittest
from lib import logger


class me_init(unittest.TestCase):

    def setUp(self):
        self.hs = SubSession("https://napi.yonyoucloud.com/")

    def test_sendVerifyEmail(self):
        """绑定邮箱时，发送验证邮件"""

        reponse = self.hs.req_func('Me_yaml/sendVerifyEmail.yaml')
        logger.info(reponse.text)
        # assert reponse.json()['error_code'] == 8028
        assert reponse.status_code == 200, '接口请求错误！返码错误！返回状态'
        # assert reponse.json()['error_code'] == 0
        # assert reponse.status_code == 200, '接口请求错误！返码错误！回状态'


if __name__ == '__main__':
    unittest.main()