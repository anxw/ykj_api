# coding:utf-8
from lib import SubSession
import unittest
from lib import logger


class Test01(unittest.TestCase):

      def setUp(self):
        self.hs = SubSession("https://napi.yonyoucloud.com/")

      def test_like(self):
        """动态-喜欢"""

        reponse = self.hs.req_func('DT_yaml/like.yaml')
        logger.info(reponse.text)
        assert reponse.status_code == 200, '接口请求错误！返码错误！返回状态'
        # assert reponse.json()['error'] == 'ddd'




if __name__ == '__main__':
    unittest.main()
