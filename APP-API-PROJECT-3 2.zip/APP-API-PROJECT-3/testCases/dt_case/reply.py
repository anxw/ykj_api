# coding:utf-8
from lib import SubSession
import unittest
from lib import logger


class Test01(unittest.TestCase):
    def setUp(self):
        self.hs = SubSession("https://napi.yonyoucloud.com/")

    def test_reply(self):
        """动态回复"""
        # global reponse

        resp = self.hs.req_func('DT_yaml/reply.yaml')
        logger.info(resp.text)
        assert resp.status_code == 200, '接口请求错误！返码错误！返回状态'
        # assert reponse.json()['error_code'] == 0




if __name__ == '__main__':
    unittest.main()
