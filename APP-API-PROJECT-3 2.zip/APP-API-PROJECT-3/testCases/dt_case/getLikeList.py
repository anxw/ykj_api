from lib import SubSession
import unittest

from lib import logger


class Test01(unittest.TestCase):

    def setUp(self):
        self.hs = SubSession("https://napi.yonyoucloud.com/")

    def test_getLikeList(self):
        """获取点赞列表"""
        # global reponse

        reponse = self.hs.req_func('DT_yaml/getLikeList.yaml')
        logger.info(reponse.text)

        assert reponse.status_code == 200, '接口请求错误！返码错误！返回状态'
        # assert reponse.json()['error_code'] == 0
        # assert reponse.status_code == 200, '接口请求错误！返码错误！回状态'
