from lib import SubSession
import unittest

from lib import logger


class Test01(unittest.TestCase):

    def setUp(self):
        self.hs = SubSession("https://napi.yonyoucloud.com/")

    def test_setTop(self):
        """动态置顶"""
        # global reponse

        reponse = self.hs.req_func('DT_yaml/setTop.yaml')
        logger.info(reponse.text)
        assert reponse.json()['error_description'] == '操作成功'
        assert reponse.status_code == 200, '接口请求错误！返码错误！返回状态'


if __name__ == '__main__':
    unittest.main()