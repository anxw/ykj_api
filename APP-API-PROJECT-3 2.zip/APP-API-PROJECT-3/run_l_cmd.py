# coding:utf-8

import subprocess
import sys, os
import getopt
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)


def main(s_value, t_file):
    from lib import get_root_path

    py_file = get_root_path() + os.sep + t_file
    # print py_file
    if str(s_value) == '1':
        """
            适用于对接口进行一次请求。
        """
        cmd = ['locust', '-f', '%s' % py_file, '-c', '1', '-r', '1', '-n', '1', '--no-web']
        # print cmd
        r = subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        std_out,std_err = r.communicate()
        print(std_out)
        print(std_err)
    else:
        """
            需要在locust的子类中指定要访问的服务器host。如locust_demo中的WebsiteUser类下面的host指定。
        """
        cmd = ['locust', '-f', '%s' % py_file]
        r = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        std_out, std_err = r.communicate()
        print(std_out)
        print(std_err)


def useage():
    print("""
    支持接口的单次请求和对单个接口的压力测试,单次接口的运行是在no-web形式下运行的；压力
    测试则在web下进行。
        -h or --help  获取帮助
        -s or --single  是否只运行一次,参数值为1（运行一次） and 0（多次运行，用于压力测试）
        -f or --file 需要测试的.py文件
    """)

opt, args = getopt.getopt(sys.argv[1:], 'hs:f:', ['help','single=','file='])
# print opt
if len(sys.argv) == 1:
    raise ValueError('参数输入错误，请检查参数是否输入正确！')
for opt_name, opt_value in opt:
    if opt_name in ('-h','--help'):
        useage()
        sys.exit()
    elif opt_name in ('-s', '--sigle'):
        # global s_value
        s_value= opt_value
        # sys.exit()
        if opt_name in ('-f', '--file'):
        # global t_f
            t_f = opt_value
            main(s_value, t_f)
        # sys.exit()
    else:
        sys.exit(-1)








if __name__ == '__main__':
    # main('y')
    pass