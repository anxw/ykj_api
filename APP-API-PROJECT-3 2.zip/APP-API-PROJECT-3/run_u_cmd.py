#!/root/.pyenv/shims/python
import os
import sys

from unittest import TestLoader,TextTestResult
from lib import create_and_get_report
from lib import BSTestRunner,get_root_path
sys.path.append(os.path.split(os.path.abspath(os.path.dirname(__file__)))[0])

import getopt



def test_case_dicovery(dir_name, pattern='*.py',top_lever_file=None):
    """加载某文件下所有.py下的测试用例，并返回suite(一个套件)"""

    suite = TestLoader().discover(start_dir=dir_name,pattern=pattern,top_level_dir=top_lever_file)
    return suite


def run(dir_name, py_file=None, report_name='Test_Result', title='接口测试报告', description='友空间接口测试'):
    if py_file:

        suite = test_case_dicovery(dir_name=dir_name, pattern=py_file)
    else:
        suite = test_case_dicovery(dir_name=dir_name)

    report_template = create_and_get_report(report_name)

    r_data = {}
    info=""
    with open(report_template, 'wb') as f:
        runner = BSTestRunner(stream=f, title=title, description=description,verbosity=2)
        result = runner.run(suite)
        total = result.success_count+result.failure_count+result.error_count
        r_data['成功'] = result.success_count
        r_data['失败'] = result.failure_count
        r_data['错误'] = result.error_count
        with open(get_root_path()+os.sep+'logFile'+os.sep+'temp_file.txt','wb') as fl:
            info += "运行测试用例总数:%d\n" % total
            for k,v in r_data.items():
                info += "%s:%d\n" % (k, v)
            fl.write(info.encode('utf-8'))


def useage():
    print("""
    支持接口的单次请求和对单个接口的压力测试,单次接口的运行是在no-web形式下运行的；压力
    测试则在web下进行。
        -h or --help  获取帮助
        -d or --dirname  测试用例的存放文件目录名
        -f or --file 需要测试的.py文件
    """)



def main():
    t_f = None
    r_n = "Test_Result"
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'hd:f:r:', ['help','dir-name=','file=',"report-name="])
    except getopt.GetoptError:
        print('GetoptError, usage: run_u_cmd.py -d <testCases or other > -f <test_xxx.py> -r <report name>')

        sys.exit(2)

    # print opt
    if len(sys.argv) == 1:
        raise ValueError('参数输入错误，请检查参数是否输入正确！')
    for opt, arg in opts:
        if opt in ('-h','--help'):
            useage()
            sys.exit()
        elif opt in ('-d', '--dir-name'):
            global s_value
            s_value = arg

        elif opt in ('-f', '--file'):

            t_f = arg
        elif opt in ('-r', '--reprot-name'):
            r_n = arg

        else:
            sys.exit(-1)
    run(s_value, t_f, r_n)


if __name__ == "__main__":
    main()
