import hashlib
import requests
import json
from lib import logger


def md5_data(strData):
    """
    对字符串进行md5加密处理
    :param strData:
    :return:
    """
    if not isinstance(strData, str):
        raise TypeError("参数类型错误，请检查是否是string类型！")
    md = hashlib.md5()
    md.update(strData.encode('utf-8'))
    return md.hexdigest()


def sort_data(dictData, reverse=False):
    """
    对字典类型数据进行排序处理，并按k=v的格式进行拼接返回。
    :param dictData:
    :param reverse: 默认为False,升序排列.
    :return:
    """
    if not isinstance(dictData, dict):
        raise TypeError("要排序的参数类型错误，请检查是否是dict类型！")

    dataStr = ""
    items = sorted(dictData.items(), key=lambda d: d[0], reverse=reverse)
    for k, v in items:
        dataStr += '%s=%s' % (k, v)

    return dataStr


class ImMessage(requests.Session):

    def _get_public_token(self):
        data = {
            "appid": "9ad99e4505b4d4ab",
            "secret": "dac8be17266b965cafef4912d1cff0383fc9f263b76d354cbff3b3bd6747"
        }

        resp = self.get('https://openapi.yonyoucloud.com/token', params=data)
        return resp.json()['data']['access_token']

    def send_im_message(self, content, receiver, report_name=None, title=None, m_type=1):
        """

        :param title:对应分享消息，默认为None
        :param content:消息内容，对应分享消息类型的desc参数。
        :param receiver: 接收信息的一方，可以为list类型，也可以为string类型。如果是string类型只能是一个用户，多个用户
        可以使用数组的形式如：['a','b']
        :param report_url: 测试报告的url地址
        :param m_type: 消息类型：1、文本；2、分享消息
        :return:
        """
        global users
        users = []
        if not isinstance(receiver, list):
            if isinstance(receiver, str):
                users.append(receiver)
            else:
                raise TypeError("接收用户receiver参数类型错误!请核对是否是list or str 类型！")
        else:
            users = receiver

        token = self._get_public_token()
        if m_type == 1:

            url = 'https://openapi.yonyoucloud.com/rest/message/service/txt?access_token=%s' % token

            data = {
                "spaceId": "5417",
                "pubAccId": "jiraykj",
                "sendScope": "list",
                "to": users,
                "content": content

            }
        elif m_type == 2:

            if not title:
                raise ValueError("参数title不能为空！")
            url = 'https://openapi.yonyoucloud.com/rest/message/service/share?access_token=%s' % token
            report_url = 'http://10.11.66.47:8089/%s' % report_name
            data = {

                "spaceId": "5417",
                "pubAccId": "jiraykj",
                "sendThrough": "appNotify",
                "sendScope": "list",
                "to": users,
                "title": title,
                "desc": content,
                "detailUrl": report_url


            }
        header = {
            "Content-Type": "application/json"
        }
        resp = self.post(url, data=json.dumps(data), headers=header)
        if resp.json()['flag'] == 0:

            logger.info("服务号信息发送成功！")
        else:
            logger.warn("服务号信息发送失败！")
        return

if __name__ == '__main__':
    pass
