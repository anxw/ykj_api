     # -*- coding:utf-8 -*-
"""
功能介绍：封装了一些常用的基础方法
注意：在get_root_path方法中如果更改项目名称，比如：将‘APP_GUI_PROJECT’更改为‘abc’,则需要将get_root_path方法下的‘APP_I_PROJECT’修改为‘abc’
"""
import sys, os
import yaml
from backports.configparser2 import ConfigParser
import inspect
curPath = os.path.abspath(os.path.dirname(__file__))

rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)


NAME = lambda p : os.path.basename(p).split('.')[0]


def get_root_path():
    """
    获取工程根目录
    :return:
    """
    try:
        path = os.path.dirname(os.path.dirname(inspect.getsourcefile(get_root_path)))

        p_name = os.path.basename(path)
        # print path, p_name
        if '/' in path:
            _list = path.split('/')
        else:
            _list = path.split(os.sep)
        # print _list
        return os.sep.join(_list[:_list.index(p_name) + 1])
    except Exception as e:
        raise e


def getLogDir():
    """
    返回logfile文件路径
    :return:
    """
    logFilePath = get_root_path()+ os.sep+'logFile'
    if not os.path.exists(logFilePath):
        os.mkdir(logFilePath)
        return os.path.abspath(logFilePath)
    else:
        return os.path.abspath(logFilePath)


def create_and_get_report(f_name):
    """
    在当前工程指定目录下创建测试报告模板
    :return:
    """
    if not os.path.exists(get_root_path() + os.sep+'report'):
        os.mkdir(get_root_path() + os.sep+'report')

    if not os.path.exists(get_root_path() + os.sep+'report'+os.sep+'%s.html' % (f_name,)):
        os.chdir(get_root_path() + os.sep+'report')
        f = open(os.getcwd() + os.sep+'%s.html' % (f_name,), 'wb')
        f.close()
        return os.path.join(os.getcwd(), '%s.html' % (f_name,))
    else:
        return os.path.join(get_root_path() + os.sep+'report', '%s.html' % (f_name,))


def yaml_load(filename):
    """
    读取yaml配置文件
    :param filename: 要读取的文件名
    :return: 
    """
    dirname = get_root_path()+os.sep+'apiConfig'+os.sep + filename
    # print dirnamea
    try:
        with open(dirname, encoding='utf-8') as f:

            ft = yaml.load(f)

    except Exception as e:
        raise Exception(e)
    return ft
def yaml_load_(filename):
    """
    读取yaml配置文件
    :param filename: 要读取的文件名
    :return:
    """
    dirname = get_root_path()+os.sep+'basicConfig'+os.sep + filename
    # print dirnamea
    try:
        with open(dirname, encoding='utf-8') as f:

            ft = yaml.load(f)

    except Exception as e:
        raise Exception(e)
    return ft


def read_conf(conf_path):
    """

    :param conf_path: ***.ini or ***.txt or ***.conf等格式文件，在config/下。
    :return: 
    """
    try:
        hd = ConfigParser()
        hd.read(get_root_path() + os.sep + 'basicConfig' + os.sep + conf_path, encoding='utf-8')
        return hd
    except Exception as e:
        raise e


def yaml_load_all(file_name):
    file_path = get_root_path() + os.sep + 'apiConfig' + os.sep + file_name

    try:
        with open(file_path,encoding='utf-8') as f:
            data = yaml.load_all(f.read())

    except Exception as e:
        raise e
    return data


def get_req_data(obj, conf_name):
    """
    获取某个文件里的所有内容
    :param obj: 数据内容所在的模块。
    :return:
    """
    request_data = {}

    if hasattr(obj, conf_name):
        data = getattr(obj, conf_name)
        request_data.update(data)
        # print request_data
    else:
        raise ValueError("%s 在conf.py文件中不存在" % conf_name)
    return request_data





if __name__ == '__main__':
    print(getLogDir())
