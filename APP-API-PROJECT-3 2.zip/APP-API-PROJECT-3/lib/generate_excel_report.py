
from __future__ import division
import time, os
import xlsxwriter
from lib import get_root_path
import sqlite3
from decimal import Decimal
import sys



def get_test_cases_total_num(cursor,test_date=None):
    if test_date:
        cursor.execute('select count(*) from api_test where test_date="%s";'% test_date)
    else:
        cursor.execute('select count(*) from api_test ;')
    icount = cursor.fetchone()[0]
    return int(icount)


def get_success_num(cursor, test_date=None):
    if test_date:
        cursor.execute('select count(*) from api_test where req_result="Pass" and test_date="%s";'% test_date)
    else:
        cursor.execute('select count(*) from api_test where req_result="Pass";')
    icount = cursor.fetchone()[0]
    return int(icount)


def get_fail_num(cursor,test_date=None):
    return get_test_cases_total_num(cursor, test_date)-get_success_num(cursor, test_date)


# def get_all_data(cursor):
#     cursor.execute('select * from api_test;')
#     ad = cursor.fetchall()
#     return ad


def get_format(wd, option={}):
    return wd.add_format(option)


# 设置居中
def get_format_center(wd, num=1):
    _format = wd.add_format({'align': 'center', 'valign': 'vcenter', 'border': num})
    _format.set_text_wrap()
    return _format


def _get_format_center(wd,num=1):
    _format = wd.add_format({'align': 'center', 'valign': 'vcenter', 'border': num, 'bg_color':'#EE0000'})\
        .set_text_wrap()
    return _format


def set_border_(wd, num=1):
    return wd.add_format({}).set_border(num)


# 写数据
def __write_center(worksheet, cl, data, wd):
    return worksheet.write(cl, data, _get_format_center(wd))


def _write_center(worksheet, cl, data, wd):
    return worksheet.write(cl, data, get_format_center(wd))


def init(worksheet, workbook, test_date=None):
    """
    测试概况sheet页的格式、数据生成。
    :param worksheet:
    :param workbook:
    :param test_date:
    :return:
    """
    # 设置列行的宽高
    worksheet.set_column("A:A", 15)
    worksheet.set_column("B:B", 20)
    worksheet.set_column("C:C", 20)
    worksheet.set_column("D:D", 20)
    worksheet.set_column("E:E", 20)
    worksheet.set_column("F:F", 20)

    worksheet.set_row(1, 30)
    worksheet.set_row(2, 30)
    worksheet.set_row(3, 30)
    worksheet.set_row(4, 30)
    worksheet.set_row(5, 30)
    # worksheet.set_row(0, 200)

    define_format_H1 = get_format(workbook, {'bold': True, 'font_size': 18})
    # define_format_H2 = get_format(workbook, {'bold': True, 'font_size': 14})
    define_format_H1.set_border(1)

    # define_format_H2.set_border(1)
    define_format_H1.set_align("center")
    # define_format_H2.set_align("center")
    define_format_H1.set_bg_color("blue")
    define_format_H1.set_color("#ffffff")
    # Create a new Chart object.

    worksheet.merge_range('A1:F1', '测试报告summary', define_format_H1)
    # worksheet.merge_range('A2:F2', '测试摘要', define_format_H2)
    worksheet.merge_range('A2:A5', '友空间业务接口', get_format_center(workbook))

    _write_center(worksheet, "B2", '项目名称', workbook)
    _write_center(worksheet, "B3", '接口版本', workbook)
    _write_center(worksheet, "B4", '脚本语言', workbook)
    _write_center(worksheet, "B5", '网络协议', workbook)

    data = {"test_name": "友空间接口测试", "test_version": "未定", "test_pl": "Python", "test_net": "http/https"}
    _write_center(worksheet, "C2", data['test_name'], workbook)
    _write_center(worksheet, "C3", data['test_version'], workbook)
    _write_center(worksheet, "C4", data['test_pl'], workbook)
    _write_center(worksheet, "C5", data['test_net'], workbook)

    _write_center(worksheet, "D2", "接口总数", workbook)
    _write_center(worksheet, "D3", "通过总数", workbook)
    _write_center(worksheet, "D4", "失败总数", workbook)
    _write_center(worksheet, "D5", "测试日期", workbook)

    date = time.strftime("%Y-%m-%d", time.localtime(time.time()))
    data1 = {"test_sum": get_test_cases_total_num(sd.get_cursor, test_date),
             "test_success": get_success_num(sd.get_cursor,test_date),
             "test_failed": get_fail_num(sd.get_cursor,test_date),
             "test_date": date}
    _write_center(worksheet, "E2", data1['test_sum'], workbook)
    _write_center(worksheet, "E3", data1['test_success'], workbook)
    _write_center(worksheet, "E4", data1['test_failed'], workbook)
    _write_center(worksheet, "E5", data1['test_date'], workbook)

    _write_center(worksheet, "F2", "通过率", workbook)
    #
    sucess_sum = get_success_num(sd.get_cursor, test_date)
    total_sum = get_test_cases_total_num(sd.get_cursor, test_date)
    pass_pecent = Decimal((sucess_sum/total_sum)*100).quantize(Decimal('0.00'))
    # print "@@@@@@@@@"+str(pass_pecent)

    worksheet.merge_range('F3:F5', str(pass_pecent) + '%', get_format_center(workbook))

    pie(workbook, worksheet)


# 生成饼形图
def pie(workbook, worksheet):
    chart1 = workbook.add_chart({'type': 'pie'})
    chart1.add_series({
        'name': '测试结果分布图',
        'categories': '=测试概况!$D$3:$D$4',
        'values': '=测试概况!$E$3:$E$4',
        'points': [
            {'fill': {'color': '#5ABAFE'}},  # 第一个项目颜色
            {'fill': {'color': '#FE110E'}},  # 第二个项目颜色
        ]
    })
    chart1.set_title({'name': '测试结果分布图'})
    chart1.set_style(10)
    worksheet.insert_chart('A7', chart1, {'x_offset': 25, 'y_offset': 10})


#
def test_detail(worksheet, workbook, test_date=None):
    """
    测试详情sheet页数据生成
    :param worksheet:
    :param workbook:
    :param test_date: 对应测试用例运行完毕后，插入数据库的时间。可为空。
    :return:
    """
    # 设置列宽高
    worksheet.set_column("A:A", 30)
    worksheet.set_column("B:B", 20)
    worksheet.set_column("C:C", 20)
    worksheet.set_column("D:D", 20)
    worksheet.set_column("E:E", 20)
    worksheet.set_column("F:F", 20)
    worksheet.set_column("G:G", 20)
    worksheet.set_column("H:H", 20)

    # 设置行的宽高
    for hrow in range(get_test_cases_total_num(sd.get_cursor,test_date) + 2):
        worksheet.set_row(hrow, 30)

    worksheet.merge_range('A1:H1', '测试详情', get_format(workbook, {'bold': True,
                                                                 'font_size': 18,
                                                                 'align': 'center',
                                                                 'valign': 'vcenter',
                                                                 'bg_color': 'blue',
                                                                 'font_color': '#ffffff'}))
    _write_center(worksheet, "A2", '用例ID', workbook)
    _write_center(worksheet, "B2", '接口名称', workbook)
    _write_center(worksheet, "C2", '请求方法', workbook)
    _write_center(worksheet, "D2", '接口地址', workbook)
    _write_center(worksheet, "E2", '参数', workbook)
    _write_center(worksheet, "F2", '接口返回结果', workbook)
    _write_center(worksheet, "G2", '测试结果', workbook)
    _write_center(worksheet, "H2", '测试时间', workbook)

    sum_item = get_test_cases_total_num(sd.get_cursor, test_date) + 2
    i = 3
    if test_date:
        sd.get_cursor.execute('select * from api_test where test_date = "%s";' % test_date)
    else:
        sd.get_cursor.execute('select * from api_test;')
    while i <= sum_item:
        content = sd.get_cursor.next()
        _write_center(worksheet, "A" + str(i), content[0], workbook)
        _write_center(worksheet, "B" + str(i), content[1], workbook)
        _write_center(worksheet, "C" + str(i), content[2], workbook)
        _write_center(worksheet, "D" + str(i), content[3], workbook)
        _write_center(worksheet, "E" + str(i), content[4], workbook)
        _write_center(worksheet, "F" + str(i), content[5], workbook)
        # _write_center(worksheet, "F" + str(i), content[6], workbook)
        if content[6].lower() == 'fail':
            __write_center(worksheet, "G" + str(i), content[6], workbook)
        else:
            _write_center(worksheet, "G" + str(i), content[6], workbook)
        _write_center(worksheet, "H" + str(i), content[7], workbook)
        i = i + 1


def generate_report(test_date=None):
    now = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
    workbook = xlsxwriter.Workbook(get_root_path() + '\\report\\' + u"接口测试报告" + now + '.xlsx')  # 生成的报告的路径
    worksheet = workbook.add_worksheet("测试概况")
    worksheet2 = workbook.add_worksheet("测试详情")
    init(worksheet, workbook, test_date)
    test_detail(worksheet2, workbook, test_date)

    workbook.close()


class SqliteDB(object):
    def __init__(self, db_name):
        # if os.path.exists(get_root_path() + '\\db\\' + db_name):
            # os.rmdir(get_root_path() + '\\db\\' + db_name)

        self.conn = sqlite3.connect(get_root_path() + '\\db\\' + db_name)
        self.cursor = self.conn.cursor()

    def _create_table(self):
        try:
            self.conn.execute("create table if not exists api_test ( \
                            case_id INTEGER PRIMARY KEY,\
                            case_name VARCHAR(64) NOT NULL,\
                            req_method VARCHAR(16) NOT NULL,\
                            req_uri VARCHAR(128) NOT NULL,\
                            req_param TEXT  DEFAULT NULL,\
                            req_content TEXT NOT  NULL ,\
                            req_result VARCHAR(16) NOT NULL,\
                            test_date VARCHAR(16) DEFAULT NULL)")
        except:
            raise Exception('api_test表创建失败！')

    def drop_table(self, table_name):
        if table_name:
            self.cursor.execute('DROP TABLE IF EXISTS %s'% table_name)
            self.conn.commit()
            self.cursor.close()
            self.conn.close()
        else:
            raise ValueError('table_name 参数取值错误！')

    @property
    def get_conn(self):
        return self.conn

    @property
    def get_cursor(self):
        return self.cursor

    def insert(self, data):
        """

        :param data: data需为一个元组,且data里面的值的类型为utf-8
        :return:
        """
        if not isinstance(data, tuple):
            raise ValueError('data must be a dict!')
        self._create_table()
        if len(data) == 6:
            sql = 'INSERT INTO api_test VALUES (NULL,?,?,?,?,?,?,NULL);'
        else:
            sql = 'INSERT INTO api_test VALUES (NULL,?,?,?,?,?,?,?);'
        self.cursor.execute(sql, data)
        self.conn.commit()

    def delete_table_data(self):
        sql = 'delete from api_test;'
        self.cursor.execute(sql)
        self.conn.commit()

sd = SqliteDB('space_api.db')


def insert_data(sqlite_instance, res):
    """
    适用于通过locust做接口请求,请求结果作为数据库的插入数据。
    :param res:接口请求返回对象
    :return:
    """
    req_data = []
    if res.json()['error_code'] == '0':
        result = 'Pass'
    else:
        result = 'Fail'
    arg = res.locust_request_meta['args']
    req_data.append(res.locust_request_meta['name'])
    req_data.append(res.locust_request_meta['method'])
    req_data.append(res.locust_request_meta['uri'])
    # req_data.append(res.locust_request_meta['name'])
    args = {}

    if arg['data']:
        args['data'] = arg['data']

    req_data.append(args.__str__().decode('utf-8'))
    req_data.append(res.locust_request_meta['resp_content'].decode('utf-8'))
    req_data.append(result)
    # print req_data
    if os.path.exists(get_root_path()+ os.sep + 'db' + os.sep +'space_api.db'):
        sqlite_instance.delete_table_data()
    sqlite_instance.insert(tuple(req_data))


def test_report(sqlite_instance, res, date=None):
    """
    :param sqlite_instance: sqllite 的一个实例
    :param res: 接口请求返回对象
    :param date: 测试时间，可不填。
    :return:
    """
    insert_data(sqlite_instance, res)
    generate_report(test_date=date)

if __name__ == '__main__':

    print(sd.get_conn)
