
import re
import time, json
# from datetime import timedelta
from urllib.parse import urlparse, urlunparse
import requests
from requests import Response, Request
from requests.auth import HTTPBasicAuth
from requests.exceptions import (RequestException, MissingSchema,
                                 InvalidSchema, InvalidURL)
from urllib3.exceptions import InsecureRequestWarning
import locust.events as events
from locust.exception import CatchResponseError, ResponseError
from lib import logger
from requests_toolbelt import MultipartEncoder

absolute_http_url_regexp = re.compile(r"^https?://", re.I)


class LocustResponse(Response):
    def raise_for_status(self):
        if hasattr(self, 'error') and self.error:
            raise self.error
        Response.raise_for_status(self)


class SubSession(requests.Session):
    """
    Class for performing web requests and holding (session-) cookies between requests (in order
    to be able to log in and out of websites). Each request is logged so that locust can display
    statistics.

    This is a slightly extended version of `python-request <http://python-requests.org>`_'s
    :py:class:`requests.Session` class and mostly this class works exactly the same. However
    the methods for making requests (get, post, delete, put, head, options, patch, request)
    can now take a *url* argument that's only the path part of the URL, in which case the host
    part of the URL will be prepended with the HttpSession.base_url which is normally inherited
    from a Locust class' host property.

    Each of the methods for making requests also takes two additional optional arguments which
    are Locust specific and doesn't exist in python-requests. These are:

    :param name: (optional) An argument that can be specified to use as label in Locust's statistics instead of the URL path.
                 This can be used to group different URL's that are requested into a single entry in Locust's statistics.
    :param catch_response: (optional) Boolean argument that, if set, can be used to make a request return a context manager
                           to work as argument to a with statement. This will allow the request to be marked as a fail based on the content of the
                           response, even if the response code is ok (2xx). The opposite also works, one can use catch_response to catch a request
                           and then mark it as successful even if the response code was not (i.e 500 or 404).
    """

    def __init__(self, base_url, *args, **kwargs):
        requests.Session.__init__(self, *args, **kwargs)

        self.base_url = base_url
        self.ek = ""
        self.request_meta = {}
        # Check for basic authentication
        parsed_url = urlparse(self.base_url)
        if parsed_url.username and parsed_url.password:
            netloc = parsed_url.hostname
            if parsed_url.port:
                netloc += ":%d" % parsed_url.port

            # remove username and password from the base_url
            self.base_url = urlunparse(
                (parsed_url.scheme, netloc, parsed_url.path, parsed_url.params, parsed_url.query, parsed_url.fragment))
            # configure requests to use basic auth
            self.auth = HTTPBasicAuth(parsed_url.username, parsed_url.password)

    def _build_url(self, path):
        """ prepend url with hostname unless it's already an absolute URL """
        if absolute_http_url_regexp.match(path):
            return path
        else:
            return "%s%s" % (self.base_url, path)

    def req_func(self, file_name=None, method_=None, uri=None, header=None,
                 data_dict=None, catch_response=True, **kwargs):
        """

        :param file_name: 读取参数信息的配置文件，yaml格式
        :param method_: 请求方法，如果为None,则以配置文件中的method方法为主
        :param uri: 同上
        :param header: 同上
        :param data_dict: 同上
        :param catch_response:是否抓取请求返回内容
        :param kwargs: 其他参数，具体可查看requests模块
        :return:
        """
        from lib import yaml_load
        from YKJApi import md5_data, sort_data
        request_data={}

        if file_name and '.yaml' in file_name:

            global req_data

            req_data = yaml_load(file_name)
            request_data.update(req_data)
            if isinstance(req_data, dict):
                if not req_data['name']:
                    raise ValueError("接口名称不能为空！")
            else:
                raise ValueError('从配置文件读取的数据类型错误，请确认是否为dict类型！')
            data = req_data['args']['data']
            if not isinstance(data, dict):
                raise ValueError("data 参数的取值类型需为dict，如果为空请赋值为:{}")
            if req_data['token'].lower() == 'y':

                token, sn, saltStr = SubSession.get_token(self)

                data['access_token'] = token
                data['et'] = str(int(round(time.time())))
                data['language'] = 'zhs'
                if data_dict:
                    data.update(data_dict)

                data['ek'] = md5_data(sort_data(data) + saltStr + sn)
            method = req_data["method"] if not method_ else method_

            if req_data['uri'].startswith('/') or req_data['uri'].startswith('\\'):
                url = self._build_url(uri) if uri else self._build_url(req_data['uri'])
            else:
                raise ValueError("uri 接口地址起始位置缺少'/' 或者'\\'!")

            headers = req_data['args']['headers'] if not header else header

        else:
            logger.info('file_name没有指定，默认不从配置文件读取信息 ')
            data = data_dict
            headers = header
            method = method_
            url = self._build_url(uri)

        request_data["start_time"] = time.time()


        if method == 'get':

            resp = self._send_request_safe_mode(method, url, params=data,
                                            verify=False, **kwargs)
        elif method == 'post':
            if 'application/x-www-form-urlencoded' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=data,
                                                headers=headers, verify=False, **kwargs)
            elif 'application/json' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=json.dumps(data),
                                                    headers=headers, verify=False, **kwargs)
            elif 'multipart/form-data' in headers['Content-Type']:

                m = MultipartEncoder(fields=data, boundary=headers['Content-Type'].split(';')[1].split('=')[1])

                resp = self._send_request_safe_mode(method, url, data=m,
                                                         headers=headers, verify=False, **kwargs)

            else:
                raise ValueError('content-type取值错误！')

        # 添加对 cookie的处理

        # record the consumed time
        request_data["response_time"] = int((time.time() - request_data["start_time"]) * 1000)

        # get the length of the content, but if the argument stream is set to True, we take
        # the size from the content-length header, in order to not trigger fetching of the body
        if kwargs.get("stream", False):
            request_data["content_size"] = int(resp.headers.get("content-length") or 0)
        else:
            request_data["content_size"] = len(resp.content or "")

        request_data["status_code"] = resp.status_code

        request_data["resp_content"] = resp.content

        if catch_response:
            resp.locust_request_meta = request_data
            return ResponseContextManager(resp)
        else:
            try:
                resp.raise_for_status()
            except RequestException as e:
                events.request_failure.fire(
                    request_type=request_data["method"],
                    name=request_data["name"],
                    response_time=request_data["response_time"],
                    exception=e,
                )
            else:
                events.request_success.fire(
                    request_type=request_data["method"],
                    name=req_data["name"],
                    response_time=request_data["response_time"],
                    response_length=request_data["content_size"],
                )
            return resp

    def req_locust_func(self,file_name, token=None, sn=None, catch_response=True, **kwargs):
        request_meta = {}
        if '.yaml' in file_name and file_name:
            import lib
            req_data = lib.yaml_load(file_name)

            request_meta.update(req_data)
        else:
            raise ValueError("读取的配置文件错误！")
        url = self._build_url(request_meta['uri'])

        method = request_meta["method"]
        request_meta["start_time"] = time.time()
        if isinstance(request_meta, dict):
            if not request_meta['name']:
                raise ValueError("接口名称不能为空！")
            if not request_meta['uri']:
                raise ValueError("接口地址不能为空！")
            if not request_meta['method']:
                raise ValueError("接口请求方法不能为空！")

        p = request_meta['args']

        data = p['data']

        headers = p['headers']



        from lib import yaml_load
        from YKJApi import md5_data, sort_data

        if request_meta['token'].lower() == 'y':

            rc = yaml_load('token.yaml')
            saltStr = rc['saltStr']

            data['access_token'] = token
            data['et'] = str(int(round(time.time())))
            data['language'] = 'zhs'
            data['ek'] = md5_data(sort_data(data) + saltStr + sn)

        else:

            rc = yaml_load('token.yaml')
            saltStr = rc['saltStr']
            data['ek'] = md5_data(sort_data(data) + saltStr)
        # else:
        #
        #     data['access_token'] = token

        if method == 'get':

            resp = self._send_request_safe_mode(method, url, params=data,
                                                verify=False, **kwargs)
        elif method == 'post':
            if 'application/x-www-form-urlencoded' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=data,
                                                    headers=headers, verify=False, **kwargs)
            elif 'application/json' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=json.dumps(data),
                                                    headers=headers, verify=False, **kwargs)
            elif 'multipart/form-data' in headers['Content-Type']:
                m = MultipartEncoder(fields=data, boundary=headers['Content-Type'].split(';')[1].split('=')[1])
                resp = self._send_request_safe_mode(method, url, data=m,
                                                    headers=headers, verify=False, **kwargs)

        # 添加对 cookie的处理

        # record the consumed time
        request_meta["response_time"] = int((time.time() - request_meta["start_time"]) * 1000)
        if not request_meta["name"]:
            request_meta["name"] = (resp.history and resp.history[0] or resp).request.path_url

        # get the length of the content, but if the argument stream is set to True, we take
        # the size from the content-length header, in order to not trigger fetching of the body
        if kwargs.get("stream", False):
            request_meta["content_size"] = int(resp.headers.get("content-length") or 0)
        else:
            request_meta["content_size"] = len(resp.content or "")

        # request_meta["request_headers"] = resp.request.headers
        # request_meta["request_body"] = resp.request.body
        request_meta["status_code"] = resp.status_code
        # request_meta["response_headers"] = resp.headers
        request_meta["resp_content"] = resp.content

        if catch_response:
            resp.locust_request_meta = request_meta
            return ResponseContextManager(resp)
        else:
            try:
                resp.raise_for_status()
            except RequestException as e:
                events.request_failure.fire(
                    request_type=request_meta["method"],
                    name=request_meta["name"],
                    response_time=request_meta["response_time"],
                    exception=e,
                )
            else:
                events.request_success.fire(
                    request_type=request_meta["method"],
                    name=request_meta["name"],
                    response_time=request_meta["response_time"],
                    response_length=request_meta["content_size"],
                )
            return resp

    def req_func_im(self, file_name, uri=None, catch_response=True, **kwargs):
        """适用于对IM服务器的请求"""

        request_meta = {}

        if '.yaml' in file_name and file_name:
            from lib import yaml_load
            req_data = yaml_load(file_name)
            request_meta.update(req_data)
        else:
            raise ValueError("读取的配置文件错误！")

        url = self._build_url(uri) if uri else self._build_url(request_meta['uri'])

        method = request_meta["method"]
        request_meta["start_time"] = time.time()
        if isinstance(request_meta, dict):
            if not request_meta['name']:
                raise ValueError("接口名称不能为空！")
            if not request_meta['uri']:
                raise ValueError("接口地址不能为空！")
            if not request_meta['method']:
                raise ValueError("接口请求方法不能为空！")

        p = request_meta['args']

        data = p['data']

        headers = p['headers']

        if request_meta['token'].lower() == 'y':

            token = SubSession.get_im_token(self)
            headers['Authorization'] = token

        if method.lower() == 'get' :
            if data:

                resp = self._send_request_safe_mode(method, url, params=data,headers=headers,
                                            verify=False, **kwargs)
            else:
                resp = self._send_request_safe_mode(method, url, headers=headers,
                                                    verify=False, **kwargs)
        elif method.lower() == 'post':
            if 'application/x-www-form-urlencoded' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=data,
                                                headers=headers, verify=False, **kwargs)
            elif 'application/json' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=json.dumps(data),
                                                    headers=headers, verify=False, **kwargs)
            elif 'multipart/form-data' in headers['Content-Type']:
                m = MultipartEncoder(fields=data, boundary=headers['Content-Type'].split(';')[1].split('=')[1])
                resp = self._send_request_safe_mode(method, url, data=m,
                                                    headers=headers, verify=False, **kwargs)
            else:
                raise ValueError('content-type取值错误！')
        elif method.lower() == 'delete':
            resp = self._send_request_safe_mode(method, url, headers=headers,
                                                verify=False, **kwargs)
        elif method.lower() == 'put':
            if 'application/json' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=json.dumps(data),
                                                headers=headers, verify=False, **kwargs)
            else:
                resp = self._send_request_safe_mode(method, url, params=data, headers=headers,
                                                verify=False, **kwargs)



        # 添加对 cookie的处理

        # record the consumed time
        request_meta["response_time"] = int((time.time() - request_meta["start_time"]) * 1000)
        if not request_meta["name"]:
            request_meta["name"] = (resp.history and resp.history[0] or resp).request.path_url

        # get the length of the content, but if the argument stream is set to True, we take
        # the size from the content-length header, in order to not trigger fetching of the body
        if kwargs.get("stream", False):
            request_meta["content_size"] = int(resp.headers.get("content-length") or 0)
        else:
            request_meta["content_size"] = len(resp.content or "")

        # request_meta["request_headers"] = resp.request.headers
        # request_meta["request_body"] = resp.request.body
        request_meta["status_code"] = resp.status_code
        # request_meta["response_headers"] = resp.headers
        request_meta["resp_content"] = resp.content

        if catch_response:
            resp.locust_request_meta = request_meta
            return ResponseContextManager(resp)
        else:
            try:
                resp.raise_for_status()
            except RequestException as e:
                events.request_failure.fire(
                    request_type=request_meta["method"],
                    name=request_meta["name"],
                    response_time=request_meta["response_time"],
                    exception=e,
                )
            else:
                events.request_success.fire(
                    request_type=request_meta["method"],
                    name=request_meta["name"],
                    response_time=request_meta["response_time"],
                    response_length=request_meta["content_size"],
                )
            return resp

    def _send_request_safe_mode(self, method, url, **kwargs):
        """
        Send an HTTP request, and catch any exception that might occur due to connection problems.

        Safe mode has been removed from requests 1.x.
        """
        try:
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
            return requests.Session.request(self, method, url, **kwargs)
        except (MissingSchema, InvalidSchema, InvalidURL):
            raise
        except RequestException as e:
            r = LocustResponse()
            r.error = e
            r.status_code = 0  # with this status_code, content returns None
            r.request = Request(method, url).prepare()
            return r

    def get_token(self)->tuple:
        from lib import yaml_load_
        from YKJApi import md5_data, sort_data

        rc = yaml_load_('token.yaml')
        data = rc['args']['params']

        data['ek'] = md5_data(sort_data(data)+rc['saltStr'])
        self.ek = data['ek']
        try:
            response = self.get(self.base_url+rc['uri'], params=data)

        except:
            raise ResponseError('登录接口请求错误!')
        # userData = response.json()['data']['user']
        return str(response.json()['data']['user']['access_token']), str(response.json()['data']['user']['sn']),rc['saltStr']

    def get_im_token(self)->str:
        from lib import yaml_load_
        rc = yaml_load_('im_token.yaml')
        data = rc['args']['data']
        headers = rc['args']['headers']
        try:
            resp = self.post(self.base_url+rc['uri'],data=json.dumps(data),headers=headers)
        except:
            raise ResponseError('登录接口请求错误!')
        return str(resp.json()['token'])

    def get_light_token(self)->str:
        from lib import yaml_load_

        rc = yaml_load_('light_app_token.yaml')
        data = rc['args']['data']
        try:
            resp = self.post(self.base_url+rc['uri'], params=data)

        except:
            raise ResponseError('登录接口请求错误!')
        return resp.json()['data']

    def req_func_light(self, file_name=None, uri=None, data_dict=None, method_=None, header=None,catch_response=True, **kwargs):
        """适用于对轻应用服务器的请求"""
        request_data={}

        if file_name and '.yaml' in file_name:

            global req_data
            from lib import yaml_load
            req_data = yaml_load(file_name)
            request_data.update(req_data)
            if isinstance(req_data, dict):
                if not req_data['name']:
                    raise ValueError("接口名称不能为空！")
            else:
                raise ValueError('从配置文件读取的数据类型错误，请确认是否为dict类型！')
            data = req_data['args']['data']
            if not isinstance(data, dict):
                raise ValueError("data 参数的取值类型需为dict，如果为空请赋值为:{}")
            if data_dict:
                data.update(data_dict)

            if not uri:
                if req_data['uri'].startswith('/') or req_data['uri'].startswith('\\'):
                    url = self._build_url(req_data['uri'])
                else:
                    raise ValueError("uri 接口地址起始位置缺少'/' 或者'\\'!")
            else:

                if uri.startswith('/') or uri.startswith('\\'):
                    url = self._build_url(uri)
                else:
                    raise ValueError("uri 接口地址起始位置缺少'/' 或者'\\'!")


            method = req_data["method"] if not method_ else method_


            headers = req_data['args']['headers'] if not header else header

            if req_data['token'].lower() == 'y':
                token = SubSession.get_light_token(self)
                url = url + "?token=%s" % token


        else:
            logger.info('------>file_name没有指定，默认不从配置文件读取信息<-------')
            data = data_dict
            token = SubSession.get_light_token(self)
            url = self._build_url(uri)+"?token=%s" % token
            headers = header
            method = method_

        request_data["start_time"] = time.time()

        if method.lower() == 'get':
            if data:
                resp = self._send_request_safe_mode(method, url, params=data,headers=headers,
                                            verify=False, **kwargs)
            else:
                resp = self._send_request_safe_mode(method, url, headers=headers,
                                                    verify=False, **kwargs)
        elif method.lower() == 'post':
            if 'application/x-www-form-urlencoded' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=data,
                                                headers=headers, verify=False, **kwargs)
            elif 'application/json' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=json.dumps(data),
                                                    headers=headers, verify=False, **kwargs)
            elif 'multipart/form-data' in headers['Content-Type']:
                m = MultipartEncoder(fields=data, boundary=headers['Content-Type'].split(';')[1].split('=')[1])
                resp = self._send_request_safe_mode(method, url, data=m,
                                                    headers=headers, verify=False, **kwargs)
            else:
                raise ValueError('content-type取值错误！')
        elif method.lower() == 'delete':
            resp = self._send_request_safe_mode(method, url, headers=headers,
                                                verify=False, **kwargs)
        elif method.lower() == 'put':
            if 'application/json' in headers['Content-Type']:
                resp = self._send_request_safe_mode(method, url, data=json.dumps(data),
                                                headers=headers, verify=False, **kwargs)
            else:
                resp = self._send_request_safe_mode(method, url, params=data, headers=headers,
                                                verify=False, **kwargs)

        # 添加对 cookie的处理



        request_data["response_time"] = int((time.time() - request_data["start_time"]) * 1000)

        # get the length of the content, but if the argument stream is set to True, we take
        # the size from the content-length header, in order to not trigger fetching of the body
        if kwargs.get("stream", False):
            request_data["content_size"] = int(resp.headers.get("content-length") or 0)
        else:
            request_data["content_size"] = len(resp.content or "")

        request_data["status_code"] = resp.status_code
        request_data["resp_content"] = resp.content

        if catch_response:
            resp.locust_request_meta = request_data
            return ResponseContextManager(resp)
        else:
            try:
                resp.raise_for_status()
            except RequestException as e:
                events.request_failure.fire(
                    request_type=request_data["method"],
                    name=request_data["name"],
                    response_time=request_data["response_time"],
                    exception=e,
                )
            else:
                events.request_success.fire(
                    request_type=request_data["method"],
                    name=request_data["name"],
                    response_time=request_data["response_time"],
                    response_length=request_data["content_size"],
                )
            return resp



class ResponseContextManager(LocustResponse):
    """
    A Response class that also acts as a context manager that provides the ability to manually
    control if an HTTP request should be marked as successful or a failure in Locust's statistics

    This class is a subclass of :py:class:`Response <requests.Response>` with two additional
    methods: :py:meth:`success <locust.clients.ResponseContextManager.success>` and
    :py:meth:`failure <locust.clients.ResponseContextManager.failure>`.
    """

    _is_reported = False

    def __init__(self, response):
        super(ResponseContextManager, self).__init__()
        # copy data from response to this object
        self.__dict__ = response.__dict__

    def __enter__(self):
        return self

    def __exit__(self, exc, value, traceback):
        if self._is_reported:
            # if the user has already manually marked this response as failure or success
            # we can ignore the default haviour of letting the response code determine the outcome
            return exc is None

        if exc:
            if isinstance(value, ResponseError):
                self.failure(value)
            else:
                return False
        else:
            try:
                self.raise_for_status()
            except requests.exceptions.RequestException as e:
                self.failure(e)
            else:
                self.success()
        return True

    def success(self):
        """
        Report the response as successful

        Example::

            with self.client.get("/does/not/exist", catch_response=True) as response:
                if response.status_code == 404:
                    response.success()
        """
        events.request_success.fire(
            request_type=self.locust_request_meta["method"],
            name=self.locust_request_meta["name"],
            response_time=self.locust_request_meta["response_time"],
            response_length=self.locust_request_meta["content_size"]
            # response_content=self.locust_request_meta['response_content']
        )
        self._is_reported = True

    def failure(self, exc):
        """
        Report the response as a failure.

        exc can be either a python exception, or a string in which case it will
        be wrapped inside a CatchResponseError.

        Example::

            with self.client.get("/", catch_response=True) as response:
                if response.content == "":
                    response.failure("No data")
        """
        if isinstance(exc, str):
            exc = CatchResponseError(exc)

        events.request_failure.fire(
            request_type=self.locust_request_meta["method"],
            name=self.locust_request_meta["name"],
            response_time=self.locust_request_meta["response_time"],
            exception=exc,
        )
        self._is_reported = True


if __name__ == '__main__':

    s = SubSession('http://123.103.9.204:92/')
    print(s.get_token())
