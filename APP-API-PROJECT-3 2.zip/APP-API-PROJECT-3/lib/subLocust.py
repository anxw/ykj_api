# coding:utf-8
from .client import SubSession
from locust import Locust,TaskSet
from locust.exception import *

from gevent import GreenletExit
from locust import events
import sys
from time import time
import traceback


class SubLocust(Locust):
    client = None
    """
    Instance of SubSession that is created upon instantiation of Locust. 
    The client support cookies, and therefore keeps the session between HTTP requests.
    """
    def __init__(self):
        super(SubLocust, self).__init__()
        if self.host is None:
            raise LocustError(
                "You must specify the base host. Either in the host attribute in the Locust class, or on the command line using the --host option.")
        self.client = SubSession(base_url=self.host)


class SubTaskSet(TaskSet):

    def __init__(self, parent):
        TaskSet.__init__(self, parent)

    def run(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

        try:
            if hasattr(self, "on_start"):
                self.on_start()
        except InterruptTaskSet as e:
            from six import reraise as raise_
            if e.reschedule:
                raise_(RescheduleTaskImmediately, e, sys.exc_info()[2])
            else:
                raise_(RescheduleTask, e, sys.exc_info()[2])


        while (True):
            try:
                if self.locust.stop_timeout is not None and time() - self._time_start > self.locust.stop_timeout:
                    return

                if not self._task_queue:
                    self.schedule_task(self.get_next_task())

                try:
                    self.execute_next_task()
                except RescheduleTaskImmediately:
                    pass
                except RescheduleTask:
                    self.wait()
                    # if hasattr(self, 'on_stop'):
                    #     self.on_stop()
                else:
                    self.wait()
                    if hasattr(self, 'on_stop'):
                        self.on_stop()
            except InterruptTaskSet as e:
                from six import reraise as raise_
                if e.reschedule:
                    raise_(RescheduleTaskImmediately, e, sys.exc_info()[2])
                else:
                    raise_(RescheduleTask, e, sys.exc_info()[2])
            except StopLocust:
                raise
            except GreenletExit:
                pass
            except Exception as e:
                events.locust_error.fire(locust_instance=self, exception=e, tb=sys.exc_info()[2])
                if self.locust._catch_exceptions:
                    sys.stderr.write("\n" + traceback.format_exc())
                    self.wait()
                else:
                    raise
        # if hasattr(self, "on_stop"):
        #     self.on_stop()

