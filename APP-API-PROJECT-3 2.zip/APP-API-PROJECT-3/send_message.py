import getopt
import json
import os, sys
from YKJApi import ImMessage
sys.path.append(os.path.split(os.path.abspath(os.path.dirname(__file__)))[0])


def send_message(r_person, report_name,verity=2):
    from lib import get_root_path
    im = ImMessage()

    with open(get_root_path() + os.sep + 'logFile' + os.sep + 'temp_file.txt', 'r') as f:
        im.send_im_message(f.read(), r_person, report_name, '动态、话题、工作台、日志接口自动化测试报告通知', m_type=verity)

def useage():
    print("""
    支持接口的单次请求和对单个接口的压力测试,单次接口的运行是在no-web形式下运行的；压力
    测试则在web下进行。
        -h or --help  获取帮助
        -p   信息接收方
        -r 测试报告名称
    """)


def run():

    try:
        opts, args = getopt.getopt(sys.argv[1:], 'hp:r:', ['help'])
    except getopt.GetoptError:
        print('GetoptError, usage:  -p <recive person>  -r <report name>')
        sys.exit(2)

    # print opt
    if len(sys.argv) == 1:
        raise ValueError('参数输入错误，请检查参数是否输入正确！')
    for opt, arg in opts:
        if opt in ('-h','--help'):
            useage()
            sys.exit(0)

        elif opt == '-p':
            global person_list
            person_list = arg
            if person_list.startswith('['):
                person_list = json.loads(person_list)
        elif opt == '-r':
            global report_n
            report_n = arg

        else:
            sys.exit(1)
    send_message(person_list, report_n)


if __name__=='__main__':
    run()

